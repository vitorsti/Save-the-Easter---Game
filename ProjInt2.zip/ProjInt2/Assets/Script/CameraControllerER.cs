﻿using UnityEngine;
using System.Collections;

public class CameraControllerER : MonoBehaviour {

	public PlayerContoller thePlayer;

	private Vector3 lastPlayerPosition;
	private float distancaToMoveX, distancaToMoveY;

	// Use this for initialization
	void Start () {

		thePlayer = FindObjectOfType<PlayerContoller> ();
		lastPlayerPosition = thePlayer.transform.position;
	
	}
	
	// Update is called once per frame
	void Update () {

		distancaToMoveX = thePlayer.transform.position.x - lastPlayerPosition.x;
		distancaToMoveY = thePlayer.transform.position.y - lastPlayerPosition.y;

		transform.position = new Vector3 (transform.position.x + distancaToMoveX, transform.position.y + distancaToMoveY, transform.position.z);

		lastPlayerPosition = thePlayer.transform.position;
	
	}
}
