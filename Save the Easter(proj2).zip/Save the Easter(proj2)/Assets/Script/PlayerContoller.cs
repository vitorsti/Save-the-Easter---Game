﻿using UnityEngine;
using System.Collections;

public class PlayerContoller : MonoBehaviour {

	public float moveSpeed;
	public float jumpForce;

	private Rigidbody2D myRigidbody;

	public bool grounded;
	public LayerMask whatIsGround;

	private Collider2D myCollider;

	private bool double1jump;

	// Use this for initialization
	void Start () {

		myRigidbody = GetComponent<Rigidbody2D> ();
		myCollider = GetComponent<Collider2D> ();
	
	}
	
	// Update is called once per frame
	void Update () {

		if (grounded)
			double1jump = false;

		grounded = Physics2D.IsTouchingLayers (myCollider, whatIsGround);

		if (grounded) 
		{
			myRigidbody.velocity = new Vector2 (myRigidbody.velocity.x, jumpForce);		
		}

		if (Input.GetKeyDown (KeyCode.UpArrow) && !double1jump && !grounded) 
		{

			myRigidbody.velocity = new Vector2 (GetComponent<Rigidbody2D> ().velocity.x, jumpForce);
			double1jump = true;		}

		if (Input.GetKeyDown (KeyCode.RightArrow)) 
		{
			myRigidbody.velocity = new Vector2 (moveSpeed, GetComponent<Rigidbody2D> ().velocity.y);
		}

		if (Input.GetKeyDown (KeyCode.LeftArrow)) 
		{
			myRigidbody.velocity = new Vector2 (-moveSpeed, GetComponent<Rigidbody2D> ().velocity.y);
		}
			
	}
}
